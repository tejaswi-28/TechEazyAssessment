package com.example.demo.util;

import java.util.stream.Collectors;

import com.example.demo.dto.StudentDTO;
import com.example.demo.dto.SubjectDTO;
import com.example.demo.entity.Student;
import com.example.demo.entity.Subject;

public class DTOConverter {
	public static StudentDTO convertToStudentDTO(Student student) {
        StudentDTO studentDTO = new StudentDTO();
        studentDTO.setId(student.getId());
        studentDTO.setName(student.getName());
        studentDTO.setAddress(student.getAddress());
        studentDTO.setSubjects(student.getSubjects().stream()
                .map(DTOConverter::convertToSubjectDTO)
                .collect(Collectors.toSet()));
        return studentDTO;
    }

    public static SubjectDTO convertToSubjectDTO(Subject subject) {
        SubjectDTO subjectDTO = new SubjectDTO();
        subjectDTO.setId(subject.getId());
        subjectDTO.setName(subject.getName());
        return subjectDTO;
    }
}
