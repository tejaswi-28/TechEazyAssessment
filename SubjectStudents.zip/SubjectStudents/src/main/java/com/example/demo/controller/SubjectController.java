package com.example.demo.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.SubjectDTO;
import com.example.demo.entity.Subject;
import com.example.demo.repository.SubjectRepository;

@RestController
@RequestMapping("/subjects")
public class SubjectController {

	@Autowired
	SubjectRepository repo;
	
	@PostMapping
	public String insertSubject(@RequestBody Subject subject) {
		repo.save(subject);
		
		return "Subjects inserted";
	}
	
	@GetMapping
//	public List<Subject> getSubjects(@RequestBody Subject subject){
//		return repo.findAll();
//	}
//	public List<SubjectDTO> getAllSubjects() {
//        return repo.findAll().stream()
//            .map(subject -> new SubjectDto(subject.getId(), subject.getName()))
//            .collect(Collectors.toList());
//    }
	public List<SubjectDTO> getSubject(@RequestBody Subject subject){
		return repo.findAll().stream()
	            .map(subjects -> new SubjectDTO(subject.getId(), subject.getName()))
	            .collect(Collectors.toList());
	}
}
