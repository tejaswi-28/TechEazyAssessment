package com.example.demo.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.StudentDTO;
import com.example.demo.entity.Student;
import com.example.demo.entity.Subject;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.SubjectRepository;
import com.example.demo.util.DTOConverter;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	@Autowired
	private StudentRepository studentRepository;

    @Autowired
    private SubjectRepository subjectRepository;

    @PostMapping
    public ResponseEntity<StudentDTO> createStudent(@RequestBody Student student) {
        Set<Subject> persistedSubjects = new HashSet<>();
        for (Subject subject : student.getSubjects()) {
            Subject persistedSubject = subjectRepository.findByName(subject.getName());
            if (persistedSubject == null) {
                persistedSubject = subjectRepository.save(subject);
            }
            persistedSubjects.add(persistedSubject);
        }
        student.setSubjects(persistedSubjects);
        Student savedStudent = studentRepository.save(student);
        return new ResponseEntity<>(DTOConverter.convertToStudentDTO(savedStudent), HttpStatus.CREATED);
    }

    @GetMapping
    public List<StudentDTO> getAllStudents() {
        return studentRepository.findAll().stream()
                .map(DTOConverter::convertToStudentDTO)
                .collect(Collectors.toList());
    }
}
