import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Student } from '../models/student.model';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  students: Student[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.fetchStudents();
  }

  fetchStudents(): void {
    this.apiService.getStudents().subscribe(students => {
      this.students = students;
    });
  }
}
