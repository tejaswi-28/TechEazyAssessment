import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Subject } from '../models/subject.model';

@Component({
  selector: 'app-subjects',
  templateUrl: './subjects.component.html',
  styleUrls: ['./subjects.component.css']
})
export class SubjectsComponent implements OnInit {
  subjects: Subject[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.fetchSubjects();
  }

  fetchSubjects(): void {
    this.apiService.getSubjects().subscribe(subjects => {
      this.subjects = subjects;
    });
  }
}
