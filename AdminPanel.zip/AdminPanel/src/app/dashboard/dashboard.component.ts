import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Student } from '../models/student.model';
import { Subject } from '../models/subject.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  students: Student[] = [];
  subjects: Subject[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.apiService.getStudents().subscribe(students => {
      this.students = students;
    });

    this.apiService.getSubjects().subscribe(subjects => {
      this.subjects = subjects;
    });
  }
}
