import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Student } from '../models/student.model';
import { Subject } from '../models/subject.model';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  students: Student[] = [];
  subjects: Subject[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.apiService.getStudents().subscribe(students => {
      this.students = students;
    });

    this.apiService.getSubjects().subscribe(subjects => {
      this.subjects = subjects;
    });
  }
}
