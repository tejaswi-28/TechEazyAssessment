import { Subject } from "./subject.model";

export interface Student {
    id?: number;
    name: string;
    address: string;
    subjects?: Subject[];
}
  