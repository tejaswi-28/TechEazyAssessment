import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Student } from '../models/student.model';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit {
  students: Student[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    // Initial fetch or empty initialization
  }

  fetchStudents(): void {
    this.apiService.getStudents().subscribe(students => {
      this.students = students;
    });
  }
}
