import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username:string ='';
  errorMessage:string ='';

  constructor(private router: Router) { }

  onLogin(){
    if (this.username === 'invalid.user'){
      this.errorMessage = 'Invalid user. Please try again.';
    } else if (this.username === 'student.user') {
      this.router.navigate(['/dashboard/student']);
    } else if (this.username === 'admin.user') {
      this.router.navigate(['/dashboard/admin']);
    } else {
      this.errorMessage = 'Unknown user type.';
    }
  }
}
